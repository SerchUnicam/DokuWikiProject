<?php
dbg_deprecated('Autoloading. Do not require() files yourself.');
