<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Torpedo <dgtorpedo@gmail.com>
 */
$lang['connectfail']           = 'LDAP non è in grado di connettere: %s';
$lang['domainfail']            = 'LDAP non è in grado di trovare il tuo DN utente';
